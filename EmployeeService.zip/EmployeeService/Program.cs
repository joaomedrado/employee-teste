using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using EmployeeService.Data;

var builder = WebApplication.CreateBuilder(args);

// ------------ Config ------------
builder.Services.AddHttpContextAccessor();

// Conex�o MySQL/TiDB (via env var ConnectionStrings__Default)
var conn = builder.Configuration.GetConnectionString("Default")
           ?? Environment.GetEnvironmentVariable("ConnectionStrings__Default")
           ?? throw new InvalidOperationException("Missing connection string");

builder.Services.AddDbContext<AppDbContext>(opt =>
    opt.UseMySql(conn, ServerVersion.AutoDetect(conn)));

// Firebase Auth (env var Firebase__ProjectId = vertis-1cc7e)
var firebaseProjectId = builder.Configuration["Firebase:ProjectId"]
                        ?? Environment.GetEnvironmentVariable("Firebase__ProjectId")
                        ?? throw new InvalidOperationException("Missing Firebase ProjectId");

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(o =>
    {
        o.Authority = $"https://securetoken.google.com/{firebaseProjectId}";
        o.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = $"https://securetoken.google.com/{firebaseProjectId}",
            ValidateAudience = true,
            ValidAudience = firebaseProjectId,
            ValidateLifetime = true
        };
    });

builder.Services.AddAuthorization();

// CORS (env var CORS__AllowedOrigins: "http://localhost:9090,https://seu-app.vercel.app")
var allowed = (builder.Configuration["CORS:AllowedOrigins"]
              ?? Environment.GetEnvironmentVariable("CORS__AllowedOrigins")
              ?? "")
              .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

builder.Services.AddCors(p =>
{
    p.AddPolicy("app", cors =>
    {
        if (allowed.Length > 0) cors.WithOrigins(allowed).AllowAnyHeader().AllowAnyMethod();
        else cors.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod(); // fallback
    });
});

builder.Services.AddControllers()
    .AddJsonOptions(o =>
    {
        o.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
        o.JsonSerializerOptions.PropertyNamingPolicy = null;
    });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// ------------ DB migrate on start ------------
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    await db.Database.MigrateAsync();
}

// ------------ Pipeline ------------
app.UseCors("app");
app.UseAuthentication();
app.UseAuthorization();

var enableSwagger =
    builder.Configuration.GetValue<bool?>("Swagger:Enabled") ??
    !app.Environment.IsProduction(); // habilita em dev; em prod via env var

if (enableSwagger)
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapControllers();
app.MapGet("/healthz", () => Results.Ok("ok"));
app.Run();
