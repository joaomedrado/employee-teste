﻿// EmployeeService/Data/AppDbContext.cs
using EmployeeService.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace EmployeeService.Data
{
    public class AppDbContext : DbContext
    {
        private readonly IHttpContextAccessor _http;

        public AppDbContext(DbContextOptions<AppDbContext> options, IHttpContextAccessor http)
            : base(options) => _http = http;

        public DbSet<EmployeeModel> Employees => Set<EmployeeModel>();

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            var user = _http.HttpContext?.User;
            var uid = user?.FindFirst("user_id")?.Value ?? user?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var email = user?.FindFirst(ClaimTypes.Email)?.Value;
            var now = DateTime.UtcNow;

            foreach (var e in ChangeTracker.Entries<AuditableEntity>())
            {
                if (e.State == EntityState.Added)
                {
                    e.Entity.CreatedAt = now;
                    if (!string.IsNullOrEmpty(uid)) e.Entity.CreatedByUid = uid;
                    if (!string.IsNullOrEmpty(email)) e.Entity.CreatedByEmail = email;
                }
                else if (e.State == EntityState.Modified)
                {
                    e.Entity.UpdatedAt = now;
                    if (!string.IsNullOrEmpty(uid)) e.Entity.UpdatedByUid = uid;
                }
            }
            return base.SaveChangesAsync(cancellationToken);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<EmployeeModel>(e =>
            {
                e.HasKey(x => x.Id);
                e.Property(x => x.Id).UseMySqlIdentityColumn(); // <- auto-increment no MySQL

                // (seu índice/auditoria original)
                e.Property(x => x.CreatedByUid).HasMaxLength(128);
                e.Property(x => x.CreatedByEmail).HasMaxLength(256);
                e.HasIndex(x => x.CreatedByUid);
            });

            base.OnModelCreating(modelBuilder);
        }
    }
}
