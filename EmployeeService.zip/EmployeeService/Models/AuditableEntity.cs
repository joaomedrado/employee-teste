﻿namespace EmployeeService.Models
{
    public abstract class AuditableEntity
    {
        public string? CreatedByUid { get; set; }
        public string? CreatedByEmail { get; set; }
        public DateTime CreatedAt { get; set; }

        public string? UpdatedByUid { get; set; }
        public DateTime? UpdatedAt { get; set; }

    }
}
