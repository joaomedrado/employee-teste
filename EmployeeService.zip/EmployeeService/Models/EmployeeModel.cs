﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeService.Models
{
    public class EmployeeModel : AuditableEntity
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)] // <- auto-increment
        public int Id { get; set; }        // id

        public string Name { get; set; }   // nome
        public string Position { get; set; } // cargo
        public decimal Wage { get; set; }  // salario_base
    }
}
