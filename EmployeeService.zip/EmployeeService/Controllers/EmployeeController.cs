﻿using EmployeeService.Data;
using EmployeeService.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace EmployeeService.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize] // TODAS as rotas exigem login
    public class EmployeeController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EmployeeController(AppDbContext context)
        {
            _context = context;
        }

        // UID do Firebase no token
        private string? CurrentUid =>
            User.FindFirst("user_id")?.Value ??
            User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        // Garante que há usuário autenticado (401 caso contrário)
        private ActionResult<string> RequireUid()
        {
            var uid = CurrentUid;
            if (string.IsNullOrEmpty(uid)) return Unauthorized();
            return uid!;
        }

        // GET: apenas meus registros
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EmployeeModel>>> Get()
        {
            var uidRes = RequireUid();
            if (uidRes.Result != null) return uidRes.Result!;
            var uid = uidRes.Value!;

            return await _context.Employees
                .Where(e => e.CreatedByUid == uid)
                .ToListAsync();
        }

        // GET by id: só se for meu
        [HttpGet("{id:int}")]
        public async Task<ActionResult<EmployeeModel>> Get(int id)
        {
            var uidRes = RequireUid();
            if (uidRes.Result != null) return uidRes.Result!;
            var uid = uidRes.Value!;

            var employee = await _context.Employees.FindAsync(id);
            if (employee == null) return NotFound();
            if (!string.Equals(employee.CreatedByUid, uid, StringComparison.Ordinal))
                return Forbid(); // tentando acessar registro de outro usuário

            return employee;
        }

        // POST: cria para o usuário logado (AppDbContext preencherá CreatedBy*)
        [HttpPost]
        public async Task<ActionResult<EmployeeModel>> Post([FromBody] EmployeeModel employee)
        {
            var uidRes = RequireUid();
            if (uidRes.Result != null) return uidRes.Result!;

            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(Get), new { id = employee.Id }, employee);
        }

        // PUT: só se o registro for meu; preserva metadados de criação
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Put(int id, [FromBody] EmployeeModel employee)
        {
            var uidRes = RequireUid();
            if (uidRes.Result != null) return uidRes.Result!;

            if (id != employee.Id) return BadRequest("Id do path difere do body.");

            var dbEmp = await _context.Employees
                .AsNoTracking()
                .FirstOrDefaultAsync(e => e.Id == id);

            if (dbEmp == null) return NotFound();

            if (!string.Equals(dbEmp.CreatedByUid, CurrentUid, StringComparison.Ordinal))
                return Forbid();

            // preserva dados de criação
            employee.CreatedByUid = dbEmp.CreatedByUid;
            employee.CreatedByEmail = dbEmp.CreatedByEmail;
            employee.CreatedAt = dbEmp.CreatedAt;

            _context.Entry(employee).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: só se o registro for meu
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var uidRes = RequireUid();
            if (uidRes.Result != null) return uidRes.Result!;

            var employee = await _context.Employees.FindAsync(id);
            if (employee == null) return NotFound();

            if (!string.Equals(employee.CreatedByUid, CurrentUid, StringComparison.Ordinal))
                return Forbid();

            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
